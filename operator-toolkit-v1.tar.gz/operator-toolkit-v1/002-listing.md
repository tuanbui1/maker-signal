# Maker Signal Operator Toolkit — product listing draft

**Status:** Draft only. Not a live Gumroad or Lemon Squeezy listing. No checkout. No spend.
**Date:** Sunday 16 August 2026 (ET).
**Operator:** Twitter Bot (AI agent working for Tuan Bui). Always disclose being an AI.
**Owner of money:** Tuan Bui.

---

## Title

Maker Signal Operator Toolkit — Q3 2026

## Subtitle

Three working tools that run the Field Manual: newsletter math from the 2026 medians, file pricing with a Gumroad-like take, and a Sunday kill score — offline, sourced, no login.

## 3 bullets

- Newsletter math you can actually run: list × conversion × price, LTV as price ÷ churn, and (1 − churn)¹² remaining cohort. Defaults from beehiiv’s 2026 paid report (0.62% median conversion; 13.33% AI monthly churn). The 1,000 free @ $10 @ 0.62% ≈ $62/mo line is a preset, not a promise.
- File pricing in the $30–$49 band: keep after a 13.2% take, sales to net $1,000, a $39 / $69 / $129 preset, and a warning if you type a sub-$10 pack. InsightRaider’s 2026 cut says that band converts about 28% better than sub-$10.
- A ten-question Sunday kill scorecard (carrying vs dragging, zombie MRR, hit-rate, related-to-the-portfolio). Score plus a plain-language kill / commit-one-week / keep. Answers stay in the browser. No network.

## Who it's for

Solo makers, indie hackers, and AI-assisted operators who already have — or will buy — the Field Manual and want the checklists as files that compute. People who will tolerate an AI author if the math is sourced and the disclosure is the first screen.

## Who it's not for

- Day traders and anyone looking for trade ideas.
- Anyone who wants a video clipper or shorts product.
- Readers who want the AI author hidden.
- People hunting prompt packs, faceless-YouTube playbooks, or a $9 impulse SKU.
- Anyone who needs a live community, DMs, or “done for you” fulfillment. This is a file.

## What's inside ($39)

A self-contained HTML app plus two worksheets:

1. `002-toolkit.html` — three tools, inline CSS and JS, works offline after you open it. No backend. No email capture. No analytics beacon.
2. `002-worksheets.csv` — Sunday scorecard columns you can duplicate in Sheets.
3. `002-pricing-sheet.csv` — newsletter-math and file-pricing example rows using the sourced defaults.

Sibling to the $39 Field Manual (Experiment 001), not a reprint of it. Optional later packaging: this toolkit as the extra in a $69 Operator pack. Not listed live.

## Price

**$39** (standard). Suggested, not live.

InsightRaider’s June 2026 analysis of 146,271 Gumroad products puts the conversion sweet spot at $30–$49 (about 28% better than sub-$10). Software averages $39.95. Those are estimates from public listings, not a promise that this file will sell.

Source: https://insightraider.com/en/answers/how-to-price-digital-templates

## AI disclosure (paste on the listing)

Maker Signal is written by an AI agent (Twitter Bot) working for Tuan Bui. Tuan is the owner. Any money belongs to Tuan. We disclose this on every issue and every listing. We use AI to research and draft; we do not invent numbers, screenshots, or testimonials. If a claim does not have a live source, it does not ship. Not financial advice.

## Refund one-liner

If the HTML tools do not compute the sourced examples (including 1,000 × $10 × 0.62% ≈ $62/mo) or the scorecard does not run offline, email the owner within 14 days for a full refund. No testimonials were invented to sell this.

## What this listing is not

Not posted. Not a Lemon Squeezy or Gumroad product. Not an ApexClip pitch. Not a trade-idea product. Checkout, KYC, and payouts wait for Tuan.
